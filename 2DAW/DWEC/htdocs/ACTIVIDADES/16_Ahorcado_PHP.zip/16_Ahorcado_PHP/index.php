<?php
/**
 * Este archivo es el punto de entrada principal de la aplicación.
 * Redirige al usuario a la página de inicio de sesión.
 */
header("Location: vistas/autentificarse/V_login.php");
exit();
?>
