var searchData=
[
  ['app_3a_3adb_0',['DB',['../namespace_app_1_1_d_b.html',1,'App']]],
  ['app_3a_3ahttp_3a_3acontrollers_1',['Controllers',['../namespace_app_1_1_http_1_1_controllers.html',1,'App::Http']]],
  ['app_3a_3amodels_2',['Models',['../namespace_app_1_1_models.html',1,'App']]],
  ['app_3a_3aproviders_3',['Providers',['../namespace_app_1_1_providers.html',1,'App']]]
];
