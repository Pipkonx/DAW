var class_app_1_1_http_1_1_controllers_1_1_c___controller =
[
    [ "getPaginationData", "class_app_1_1_http_1_1_controllers_1_1_c___controller.html#a253c9579495a01973fa0d705d0bafc24", null ],
    [ "TAREAS_POR_PAGINA", "class_app_1_1_http_1_1_controllers_1_1_c___controller.html#a7584758a7b77e4476c08f84c974c7c43", null ]
];