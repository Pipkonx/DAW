var namespace_app_1_1_providers =
[
    [ "AppServiceProvider", "class_app_1_1_providers_1_1_app_service_provider.html", "class_app_1_1_providers_1_1_app_service_provider" ]
];