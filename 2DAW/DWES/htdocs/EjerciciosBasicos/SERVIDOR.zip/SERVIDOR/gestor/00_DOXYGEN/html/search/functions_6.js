var searchData=
[
  ['listar_0',['listar',['../class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a20badbc308822475434f4e72984ef23a',1,'App\\Http\\Controllers\\C_Administrador\\listar()'],['../class_app_1_1_http_1_1_controllers_1_1_c___operario.html#a20badbc308822475434f4e72984ef23a',1,'App\\Http\\Controllers\\C_Operario\\listar()'],['../class_app_1_1_models_1_1_tareas.html#aa679f44f52b37bad2aacf1adb04fd0f7',1,'App\\Models\\Tareas\\listar()']]],
  ['login_1',['login',['../class_app_1_1_http_1_1_controllers_1_1_c___auth.html#aa311da27ba5706f5710cea7706c8eae1',1,'App::Http::Controllers::C_Auth']]],
  ['logout_2',['logout',['../class_app_1_1_http_1_1_controllers_1_1_c___auth.html#a082405d89acd6835c3a7c7a08a7adbab',1,'App::Http::Controllers::C_Auth']]]
];
