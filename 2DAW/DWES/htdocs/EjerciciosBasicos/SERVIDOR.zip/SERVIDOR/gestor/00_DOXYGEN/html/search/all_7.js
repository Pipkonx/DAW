var searchData=
[
  ['geterror_0',['getError',['../class_app_1_1_models_1_1_funciones.html#ac2ce8ee63514eef8c17e1fa5683e39df',1,'App::Models::Funciones']]],
  ['getinstance_1',['getInstance',['../class_app_1_1_d_b_1_1_d_b.html#ac93fbec81f07e5d15f80db907e63dc10',1,'App::DB::DB']]],
  ['getpaginationdata_2',['getPaginationData',['../class_app_1_1_http_1_1_controllers_1_1_c___controller.html#a253c9579495a01973fa0d705d0bafc24',1,'App::Http::Controllers::C_Controller']]],
  ['guardar_3',['guardar',['../class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a7eff1139ff047569a4d8bff22dfaee0c',1,'App::Http::Controllers::C_Administrador']]]
];
