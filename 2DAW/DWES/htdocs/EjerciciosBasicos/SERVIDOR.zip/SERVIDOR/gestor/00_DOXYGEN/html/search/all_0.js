var searchData=
[
  ['_24errores_0',['$errores',['../class_app_1_1_models_1_1_funciones.html#a70fbb718980d7db3d52d37d7a5c39166',1,'App::Models::Funciones']]],
  ['_24provincias_1',['$provincias',['../class_app_1_1_models_1_1_funciones.html#aa5f6d93196a9fa2237b14ebda74d159d',1,'App::Models::Funciones']]]
];
