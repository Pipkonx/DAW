var searchData=
[
  ['index_2eblade_2ephp_0',['index.blade.php',['../index_8blade_8php.html',1,'']]]
];
