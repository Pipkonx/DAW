var searchData=
[
  ['actualizar_0',['actualizar',['../class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a8108d1d2459efc7e21d958ae07419126',1,'App\\Http\\Controllers\\C_Administrador\\actualizar()'],['../class_app_1_1_http_1_1_controllers_1_1_c___operario.html#a8108d1d2459efc7e21d958ae07419126',1,'App\\Http\\Controllers\\C_Operario\\actualizar()'],['../class_app_1_1_models_1_1_tareas.html#ab813e7f83d3646cfb75d936e810d6240',1,'App\\Models\\Tareas\\actualizar()'],['../class_app_1_1_models_1_1_usuarios.html#ae66de4ecf2c612c79d637a23ed18238a',1,'App\\Models\\Usuarios\\actualizar()']]],
  ['actualizaroperario_1',['actualizarOperario',['../class_app_1_1_models_1_1_tareas.html#a78cb382e7b13085eb377bea8230c1d9f',1,'App::Models::Tareas']]]
];
