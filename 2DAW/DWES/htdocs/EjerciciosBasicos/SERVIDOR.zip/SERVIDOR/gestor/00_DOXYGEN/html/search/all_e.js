var searchData=
[
  ['usuarios_0',['Usuarios',['../class_app_1_1_models_1_1_usuarios.html',1,'App::Models']]],
  ['usuarios_2ephp_1',['Usuarios.php',['../_usuarios_8php.html',1,'']]]
];
