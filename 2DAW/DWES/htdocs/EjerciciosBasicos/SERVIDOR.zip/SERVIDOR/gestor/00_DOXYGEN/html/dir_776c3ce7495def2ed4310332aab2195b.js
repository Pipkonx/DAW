var dir_776c3ce7495def2ed4310332aab2195b =
[
    [ "Funciones.php", "_funciones_8php.html", "_funciones_8php" ],
    [ "Tareas.php", "_tareas_8php.html", "_tareas_8php" ],
    [ "Usuarios.php", "_usuarios_8php.html", "_usuarios_8php" ]
];