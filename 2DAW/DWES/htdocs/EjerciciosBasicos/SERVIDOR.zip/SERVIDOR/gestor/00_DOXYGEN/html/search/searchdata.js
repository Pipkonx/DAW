var indexSectionsWithContent =
{
  0: "$abcdefgilmprtuvw",
  1: "acdftu",
  2: "a",
  3: "acdefilptuw",
  4: "abcegilmrtv",
  5: "$rt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Estructuras de datos",
  2: "Espacios de nombres",
  3: "Archivos",
  4: "Funciones",
  5: "Variables"
};

