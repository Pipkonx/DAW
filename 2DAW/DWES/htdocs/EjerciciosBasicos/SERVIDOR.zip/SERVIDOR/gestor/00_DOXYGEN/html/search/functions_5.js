var searchData=
[
  ['inicializar_0',['inicializar',['../class_app_1_1_models_1_1_usuarios.html#ac40e58e9e18a99211e4ca96e3e5f69f8',1,'App::Models::Usuarios']]],
  ['inicio_1',['inicio',['../class_app_1_1_http_1_1_controllers_1_1_c___inicio.html#acb88046a0a54d698c14758a1440a3b74',1,'App::Http::Controllers::C_Inicio']]]
];
