var searchData=
[
  ['funciones_0',['Funciones',['../class_app_1_1_models_1_1_funciones.html',1,'App::Models']]]
];
