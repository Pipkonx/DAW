var dir_fc48d152594f468300b284d0931a1459 =
[
    [ "EjerciciosBasicos", "dir_e0087976ee574b4d66c68a5e39760dd6.html", "dir_e0087976ee574b4d66c68a5e39760dd6" ]
];