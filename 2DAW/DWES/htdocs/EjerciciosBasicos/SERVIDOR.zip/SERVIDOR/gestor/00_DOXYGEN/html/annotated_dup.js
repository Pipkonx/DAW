var annotated_dup =
[
    [ "App", null, [
      [ "DB", "namespace_app_1_1_d_b.html", [
        [ "DB", "class_app_1_1_d_b_1_1_d_b.html", null ]
      ] ],
      [ "Http", null, [
        [ "Controllers", "namespace_app_1_1_http_1_1_controllers.html", [
          [ "C_Administrador", "class_app_1_1_http_1_1_controllers_1_1_c___administrador.html", "class_app_1_1_http_1_1_controllers_1_1_c___administrador" ],
          [ "C_Auth", "class_app_1_1_http_1_1_controllers_1_1_c___auth.html", "class_app_1_1_http_1_1_controllers_1_1_c___auth" ],
          [ "C_Controller", "class_app_1_1_http_1_1_controllers_1_1_c___controller.html", "class_app_1_1_http_1_1_controllers_1_1_c___controller" ],
          [ "C_Inicio", "class_app_1_1_http_1_1_controllers_1_1_c___inicio.html", "class_app_1_1_http_1_1_controllers_1_1_c___inicio" ],
          [ "C_Operario", "class_app_1_1_http_1_1_controllers_1_1_c___operario.html", "class_app_1_1_http_1_1_controllers_1_1_c___operario" ]
        ] ]
      ] ],
      [ "Models", "namespace_app_1_1_models.html", [
        [ "Funciones", "class_app_1_1_models_1_1_funciones.html", null ],
        [ "Tareas", "class_app_1_1_models_1_1_tareas.html", "class_app_1_1_models_1_1_tareas" ],
        [ "Usuarios", "class_app_1_1_models_1_1_usuarios.html", "class_app_1_1_models_1_1_usuarios" ]
      ] ],
      [ "Providers", "namespace_app_1_1_providers.html", [
        [ "AppServiceProvider", "class_app_1_1_providers_1_1_app_service_provider.html", "class_app_1_1_providers_1_1_app_service_provider" ]
      ] ]
    ] ]
];