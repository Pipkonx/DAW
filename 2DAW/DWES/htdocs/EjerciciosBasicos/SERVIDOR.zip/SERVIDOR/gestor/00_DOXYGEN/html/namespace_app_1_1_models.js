var namespace_app_1_1_models =
[
    [ "Funciones", "class_app_1_1_models_1_1_funciones.html", null ],
    [ "Tareas", "class_app_1_1_models_1_1_tareas.html", "class_app_1_1_models_1_1_tareas" ],
    [ "Usuarios", "class_app_1_1_models_1_1_usuarios.html", "class_app_1_1_models_1_1_usuarios" ]
];