var searchData=
[
  ['tareas_0',['Tareas',['../class_app_1_1_models_1_1_tareas.html',1,'App::Models']]],
  ['tareas_2ephp_1',['Tareas.php',['../_tareas_8php.html',1,'']]],
  ['tareas_5fpor_5fpagina_2',['TAREAS_POR_PAGINA',['../class_app_1_1_http_1_1_controllers_1_1_c___controller.html#a7584758a7b77e4476c08f84c974c7c43',1,'App::Http::Controllers::C_Controller']]],
  ['telefonovalido_3',['telefonoValido',['../class_app_1_1_models_1_1_funciones.html#a93020c4ba1e45c6cced574d59ebf5f71',1,'App::Models::Funciones']]]
];
