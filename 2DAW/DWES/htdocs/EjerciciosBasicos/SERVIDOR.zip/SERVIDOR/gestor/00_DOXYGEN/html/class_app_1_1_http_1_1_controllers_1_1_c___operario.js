var class_app_1_1_http_1_1_controllers_1_1_c___operario =
[
    [ "actualizar", "class_app_1_1_http_1_1_controllers_1_1_c___operario.html#a8108d1d2459efc7e21d958ae07419126", null ],
    [ "editar", "class_app_1_1_http_1_1_controllers_1_1_c___operario.html#a9b8c75d7e0712803ab9ade43acc129a2", null ],
    [ "listar", "class_app_1_1_http_1_1_controllers_1_1_c___operario.html#a20badbc308822475434f4e72984ef23a", null ],
    [ "mostrar", "class_app_1_1_http_1_1_controllers_1_1_c___operario.html#ab3493ee95f094661c13cd89ecdc692fe", null ]
];