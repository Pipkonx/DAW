var searchData=
[
  ['confirmareliminacion_0',['confirmarEliminacion',['../class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a0c69b90427ddf4b35b3c94afc05f1a28',1,'App::Http::Controllers::C_Administrador']]],
  ['contar_1',['contar',['../class_app_1_1_models_1_1_tareas.html#a08ad8dc3edf3f427d1328ab908aeaf14',1,'App::Models::Tareas']]],
  ['crear_2',['crear',['../class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a9c6be1b015497b31b59e7ce0b12013ae',1,'App\\Http\\Controllers\\C_Administrador\\crear()'],['../class_app_1_1_models_1_1_tareas.html#abe42e19b183aef5a618cc5b31dfc292b',1,'App\\Models\\Tareas\\crear()']]]
];
