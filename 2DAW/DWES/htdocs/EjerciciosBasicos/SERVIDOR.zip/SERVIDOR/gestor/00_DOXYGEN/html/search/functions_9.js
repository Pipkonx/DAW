var searchData=
[
  ['telefonovalido_0',['telefonoValido',['../class_app_1_1_models_1_1_funciones.html#a93020c4ba1e45c6cced574d59ebf5f71',1,'App::Models::Funciones']]]
];
