var searchData=
[
  ['mostrar_0',['mostrar',['../class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#ab3493ee95f094661c13cd89ecdc692fe',1,'App\\Http\\Controllers\\C_Administrador\\mostrar()'],['../class_app_1_1_http_1_1_controllers_1_1_c___operario.html#ab3493ee95f094661c13cd89ecdc692fe',1,'App\\Http\\Controllers\\C_Operario\\mostrar()']]]
];
