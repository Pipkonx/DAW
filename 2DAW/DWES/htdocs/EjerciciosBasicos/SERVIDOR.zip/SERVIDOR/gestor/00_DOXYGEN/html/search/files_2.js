var searchData=
[
  ['db_2ephp_0',['DB.php',['../_d_b_8php.html',1,'']]],
  ['detalle_2eblade_2ephp_1',['detalle.blade.php',['../detalle_8blade_8php.html',1,'']]]
];
