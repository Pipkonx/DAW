var class_app_1_1_models_1_1_usuarios =
[
    [ "actualizar", "class_app_1_1_models_1_1_usuarios.html#ae66de4ecf2c612c79d637a23ed18238a", null ],
    [ "buscar", "class_app_1_1_models_1_1_usuarios.html#ad22ce89051e009b72f7d4320f4134cb0", null ],
    [ "inicializar", "class_app_1_1_models_1_1_usuarios.html#ac40e58e9e18a99211e4ca96e3e5f69f8", null ]
];