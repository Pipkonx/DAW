var dir_8c086f3213df3168c59ba67f38782fab =
[
    [ "alta_edicion.blade.php", "alta__edicion_8blade_8php.html", null ],
    [ "confirmar_eliminacion.blade.php", "confirmar__eliminacion_8blade_8php.html", null ],
    [ "detalle.blade.php", "detalle_8blade_8php.html", null ],
    [ "edicion_operario.blade.php", "edicion__operario_8blade_8php.html", null ],
    [ "form.blade.php", "form_8blade_8php.html", null ],
    [ "lista.blade.php", "lista_8blade_8php.html", null ]
];