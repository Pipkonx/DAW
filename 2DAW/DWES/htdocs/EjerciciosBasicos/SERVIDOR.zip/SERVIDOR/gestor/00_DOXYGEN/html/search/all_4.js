var searchData=
[
  ['db_0',['DB',['../class_app_1_1_d_b_1_1_d_b.html',1,'App::DB']]],
  ['db_2ephp_1',['DB.php',['../_d_b_8php.html',1,'']]],
  ['detalle_2eblade_2ephp_2',['detalle.blade.php',['../detalle_8blade_8php.html',1,'']]]
];
