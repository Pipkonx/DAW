var searchData=
[
  ['lista_2eblade_2ephp_0',['lista.blade.php',['../lista_8blade_8php.html',1,'']]],
  ['login_2eblade_2ephp_1',['login.blade.php',['../login_8blade_8php.html',1,'']]]
];
