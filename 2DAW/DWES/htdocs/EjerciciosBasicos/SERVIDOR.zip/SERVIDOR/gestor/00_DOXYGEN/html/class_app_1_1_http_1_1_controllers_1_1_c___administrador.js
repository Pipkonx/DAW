var class_app_1_1_http_1_1_controllers_1_1_c___administrador =
[
    [ "actualizar", "class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a8108d1d2459efc7e21d958ae07419126", null ],
    [ "confirmarEliminacion", "class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a0c69b90427ddf4b35b3c94afc05f1a28", null ],
    [ "crear", "class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a9c6be1b015497b31b59e7ce0b12013ae", null ],
    [ "editar", "class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a9b8c75d7e0712803ab9ade43acc129a2", null ],
    [ "eliminar", "class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#ae05738af445a2eb4f3456604f1b9be8f", null ],
    [ "guardar", "class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a7eff1139ff047569a4d8bff22dfaee0c", null ],
    [ "listar", "class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a20badbc308822475434f4e72984ef23a", null ],
    [ "mostrar", "class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#ab3493ee95f094661c13cd89ecdc692fe", null ]
];