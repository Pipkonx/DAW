var searchData=
[
  ['validardatos_0',['validarDatos',['../class_app_1_1_models_1_1_tareas.html#ac0d9a1470895765578f055b56c180c23',1,'App::Models::Tareas']]],
  ['validarnif_1',['validarNif',['../class_app_1_1_models_1_1_funciones.html#a7be0f0481109af263f1e1fcd92627d70',1,'App::Models::Funciones']]]
];
