var namespaces_dup =
[
    [ "App", null, [
      [ "DB", "namespace_app_1_1_d_b.html", "namespace_app_1_1_d_b" ],
      [ "Http", null, [
        [ "Controllers", "namespace_app_1_1_http_1_1_controllers.html", "namespace_app_1_1_http_1_1_controllers" ]
      ] ],
      [ "Models", "namespace_app_1_1_models.html", "namespace_app_1_1_models" ],
      [ "Providers", "namespace_app_1_1_providers.html", "namespace_app_1_1_providers" ]
    ] ]
];