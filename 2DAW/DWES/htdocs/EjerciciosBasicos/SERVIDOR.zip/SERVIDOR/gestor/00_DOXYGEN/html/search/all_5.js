var searchData=
[
  ['edicion_5foperario_2eblade_2ephp_0',['edicion_operario.blade.php',['../edicion__operario_8blade_8php.html',1,'']]],
  ['editar_1',['editar',['../class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#a9b8c75d7e0712803ab9ade43acc129a2',1,'App\\Http\\Controllers\\C_Administrador\\editar()'],['../class_app_1_1_http_1_1_controllers_1_1_c___operario.html#a9b8c75d7e0712803ab9ade43acc129a2',1,'App\\Http\\Controllers\\C_Operario\\editar()']]],
  ['eliminar_2',['eliminar',['../class_app_1_1_http_1_1_controllers_1_1_c___administrador.html#ae05738af445a2eb4f3456604f1b9be8f',1,'App\\Http\\Controllers\\C_Administrador\\eliminar()'],['../class_app_1_1_models_1_1_tareas.html#ad9dd1248590702cce7f273efb0efe0d9',1,'App\\Models\\Tareas\\eliminar()']]]
];
