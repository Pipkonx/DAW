var searchData=
[
  ['appserviceprovider_0',['AppServiceProvider',['../class_app_1_1_providers_1_1_app_service_provider.html',1,'App::Providers']]]
];
