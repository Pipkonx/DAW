var class_app_1_1_models_1_1_tareas =
[
    [ "actualizar", "class_app_1_1_models_1_1_tareas.html#ab813e7f83d3646cfb75d936e810d6240", null ],
    [ "actualizarOperario", "class_app_1_1_models_1_1_tareas.html#a78cb382e7b13085eb377bea8230c1d9f", null ],
    [ "buscar", "class_app_1_1_models_1_1_tareas.html#aee76fdeb29f54c10062d70039aa3c4c9", null ],
    [ "contar", "class_app_1_1_models_1_1_tareas.html#a08ad8dc3edf3f427d1328ab908aeaf14", null ],
    [ "crear", "class_app_1_1_models_1_1_tareas.html#abe42e19b183aef5a618cc5b31dfc292b", null ],
    [ "eliminar", "class_app_1_1_models_1_1_tareas.html#ad9dd1248590702cce7f273efb0efe0d9", null ],
    [ "listar", "class_app_1_1_models_1_1_tareas.html#aa679f44f52b37bad2aacf1adb04fd0f7", null ]
];