

<?php $__env->startSection('titulo', 'Listado de Tareas'); ?>

<?php $__env->startSection('cuerpo'); ?>
  <div class="actions-container">
    <div class="left-actions">
      <?php if((isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin')): ?>
          <a href="<?php echo e(url('/admin/tareas/crear')); ?>" class="btn">Crear nueva tarea</a>
      <?php endif; ?>
    </div>
    <div class="right-actions">
      <form action="<?php echo e(url($baseUrl ?? '/admin/tareas')); ?>" method="GET" class="inline filter-form">
        <input type="text" name="q" placeholder="Buscar por descripción o operario" value="<?php echo e($_GET['q'] ?? ''); ?>">
        <select name="estado">
          <option value="">Estado</option>
          <option value="B" <?php echo e((($_GET['estado'] ?? '') === 'B') ? 'selected' : ''); ?>>Esperando ser aprobada</option>
          <option value="P" <?php echo e((($_GET['estado'] ?? '') === 'P') ? 'selected' : ''); ?>>Pendiente</option>
          <option value="R" <?php echo e((($_GET['estado'] ?? '') === 'R') ? 'selected' : ''); ?>>Realizada</option>
          <option value="C" <?php echo e((($_GET['estado'] ?? '') === 'C') ? 'selected' : ''); ?>>Cancelada</option>
        </select>
        <button type="submit" class="btn">Filtrar</button>
      </form>
    </div>
  </div>

  <h1>Tareas</h1>
  <?php if(!empty($errorGeneral)): ?>
    <div class="error"><?php echo e($errorGeneral); ?></div>
  <?php endif; ?>
  <?php if(!empty($mensaje)): ?>
    <div class="msg"><?php echo e($mensaje); ?></div>
  <?php endif; ?>

  <table>
    <thead>
                <tr>
        <th>ID</th>
        <th>Persona</th>
        <th>Descripción</th>
        <th>Fecha</th>
        <th>Estado</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($t['id']); ?></td>
          <td><?php echo e($t['personaNombre']); ?></td>
          <td><?php echo e($t['descripcionTarea']); ?></td>
          <td><?php echo e($t['fechaRealizacion']); ?></td>
          <td><?php echo e($t['estadoTarea']); ?></td>
          <td>
            
            <?php
                $rutaBase = (isset($_SESSION['rol']) && $_SESSION['rol'] === 'operario') ? 'operario/tareas' : ($baseUrl ?? 'admin/tareas');
            ?>
            
            
            <a href="<?php echo e(url($rutaBase . '/editar?id=' . $t['id'])); ?>">✏️</a>
            <a href="<?php echo e(url($rutaBase . '/detalle?id=' . $t['id'])); ?>" class="inline">👁️</a>
            <?php if((isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin')): ?>
              <a href="<?php echo e(url($rutaBase . '/confirmarEliminar?id=' . $t['id'])); ?>" class="inline">✖️</a>
            <?php endif; ?>
          </td>
        </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="6">No hay tareas</td>
        </tr>
      <?php endif; ?>


    </tbody>
  </table>

  <?php if(isset($totalPaginas) && $totalPaginas > 1): ?>
    <div class="pagination-nav">
      <?php
        $queryString = http_build_query(array_merge($_GET, ['pagina' => 1]));
      ?>
      <?php if($paginaActual > 1): ?>
        <a href="<?php echo e(url($baseUrl . '?' . http_build_query(array_merge($_GET, ['pagina' => 1])))); ?>"
          class="btn">&laquo;&laquo; Primera</a>
          
        <a href="<?php echo e(url(($baseUrl ?? '/admin/tareas') . '?' . http_build_query(array_merge($_GET, ['pagina' => $paginaActual - 1])))); ?>"
          class="btn">&laquo; Anterior</a>
      <?php endif; ?>
      <span>Página <?php echo e($paginaActual); ?> de <?php echo e($totalPaginas); ?></span>
      <?php if($paginaActual < $totalPaginas): ?>
        <a href="<?php echo e(url(($baseUrl ?? '/admin/tareas') . '?' . http_build_query(array_merge($_GET, ['pagina' => $paginaActual + 1])))); ?>"
          
          class="btn">Siguiente &raquo;</a>
        <a href="<?php echo e(url(($baseUrl ?? '/admin/tareas') . '?' . http_build_query(array_merge($_GET, ['pagina' => $totalPaginas])))); ?>"
          class="btn">Última &raquo;&raquo;</a>
      <?php endif; ?>
      <form action="<?php echo e(url($baseUrl ?? '/admin/tareas')); ?>" method="GET" class="inline">
        <?php $__currentLoopData = $_GET; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($key !== 'pagina'): ?>
            <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <input type="number" name="pagina" value="<?php echo e($paginaActual); ?>" min="1" max="<?php echo e($totalPaginas); ?>" class="btn"
>
        <button type="submit" class="btn">Ir</button>
      </form>
    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\SERVIDOR\gestor\resources\views/tareas/lista.blade.php ENDPATH**/ ?>