<?php $__env->startSection('contenido'); ?>
<h1>Gestionar Usuarios</h1>
<a href="<?php echo e(url('/admin/usuarios/crear')); ?>" class="btn">Nuevo Usuario</a>
<a href="<?php echo e(url('/admin/tareas')); ?>" class="btn">Volver a Tareas</a>

<?php if(session('exito')): ?>
    <div class="alert success"><?php echo e(session('exito')); ?></div>
<?php endif; ?>

<?php if(isset($errorGeneral)): ?>
    <div class="alert error"><?php echo e($errorGeneral); ?></div>
<?php endif; ?>

<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Rol</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($usuario['id']); ?></td>
            <td><?php echo e($usuario['nombre']); ?></td>
            <td><?php echo e($usuario['rol']); ?></td>
            <td>
                <a href="<?php echo e(url('/admin/usuarios/editar?id=' . $usuario['id'])); ?>" class="btn btn-sm">Editar</a>
                <a href="<?php echo e(url('/admin/usuarios/confirmarEliminar?id=' . $usuario['id'])); ?>" class="btn btn-sm danger">Eliminar</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php if($totalPaginas > 1): ?>
    <div class="pagination">
        <?php for($i = 1; $i <= $totalPaginas; $i++): ?>
            <a href="<?php echo e(url('/admin/usuarios?pagina=' . $i)); ?>" class="<?php echo e($i == $paginaActual ? 'active' : ''); ?>">
                <?php echo e($i); ?>

            </a>
        <?php endfor; ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\SERVIDOR\gestor\resources\views/usuarios/lista.blade.php ENDPATH**/ ?>