<div class="form-container">
    <form action="<?php echo e($formActionUrl); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php
            $isAdmin = (($_SESSION['rol'] ?? '') === 'admin');
            $isEdit = isset($id);
            $disableOperatorFields = $isAdmin && $isEdit;
        ?>
        <label>NIF/CIF:</label><br>
        <input type="text" name="nifCif" value="<?php echo e(htmlspecialchars($_POST['nifCif'] ?? ($nifCif ?? ''))); ?>"><br>
        <?php if($msg = \App\Models\M_Funciones::getError('nif_cif')): ?>
            <div class="error"><?php echo e($msg); ?></div>
        <?php endif; ?>

        <br>

        <label>Persona de contacto:</label><br>
        <input type="text" name="personaNombre"
            value="<?php echo e(htmlspecialchars($_POST['personaNombre'] ?? ($personaNombre ?? ''))); ?>"><br>
        <?php if($msg = \App\Models\M_Funciones::getError('nombre_persona')): ?>
            <div class="error"><?php echo e($msg); ?></div>
        <?php endif; ?>


        <br>
        <label>Teléfono:</label><br>
        <input type="text" name="telefono" value="<?php echo e(htmlspecialchars($_POST['telefono'] ?? ($telefono ?? ''))); ?>"><br>
        <?php if($msg = \App\Models\M_Funciones::getError('telefono')): ?>
            <div class="error"><?php echo e($msg); ?></div>
        <?php endif; ?>


        <br>

        <label>Correo electrónico:</label><br>
        <input type="text" name="correo" value="<?php echo e(htmlspecialchars($_POST['correo'] ?? ($correo ?? ''))); ?>"><br>
        <?php if($msg = \App\Models\M_Funciones::getError('correo')): ?>
            <div class="error"><?php echo e($msg); ?></div>
        <?php endif; ?>


        <br>

        <label>Descripción de la tarea:</label><br>
        <textarea
            name="descripcionTarea"><?php echo e(htmlspecialchars($_POST['descripcionTarea'] ?? ($descripcionTarea ?? ''))); ?></textarea><br>
        <?php if($msg = \App\Models\M_Funciones::getError('descripcion_tarea')): ?>
            <div class="error"><?php echo e($msg); ?></div>
        <?php endif; ?>


        <br>

        <label>Dirección:</label><br>
        <input type="text" name="direccionTarea"
            value="<?php echo e(htmlspecialchars($_POST['direccionTarea'] ?? ($direccionTarea ?? ''))); ?>"><br><br>

        <label>Población:</label><br>
        <input type="text" name="poblacion"
            value="<?php echo e(htmlspecialchars($_POST['poblacion'] ?? ($poblacion ?? ''))); ?>"><br><br>

        <label>Código Postal:</label><br>
        <input type="text" name="codigoPostal"
            value="<?php echo e(htmlspecialchars($_POST['codigoPostal'] ?? ($codigoPostal ?? ''))); ?>"><br><br>

        <label>Provincia:</label><br>
        <select name="provincia">
            <option value="">Seleccione provincia</option>
            <?php
                $provSeleccionada = $_POST['provincia'] ?? ($provincia ?? '');
            ?>
            <?php $__currentLoopData = \App\Models\M_Funciones::$provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($codigo); ?>" <?php echo e($codigo == $provSeleccionada ? 'selected' : ''); ?>>
                    <?php echo e($nombre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>

        <br>

        <label>Estado:</label>
        <?php if($disableOperatorFields): ?>
             <input type="hidden" name="estadoTarea" value="<?php echo e($_POST['estadoTarea'] ?? ($estadoTarea ?? '')); ?>">
        <?php endif; ?>
        <span class="radio-group-item"><input type="radio" id="estadoB" name="estadoTarea" value="B" <?php echo e((($_POST['estadoTarea'] ?? ($estadoTarea ?? '')) == "B") ? "checked" : ""); ?> <?php echo e($disableOperatorFields ? 'disabled' : ''); ?>> <label
                for="estadoB">Esperando ser aprobada</label></span>
        <span class="radio-group-item"><input type="radio" id="estadoP" name="estadoTarea" value="P" <?php echo e((($_POST['estadoTarea'] ?? ($estadoTarea ?? '')) == "P") ? "checked" : ""); ?> <?php echo e($disableOperatorFields ? 'disabled' : ''); ?>> <label
                for="estadoP">Pendiente</label></span>
        <span class="radio-group-item"><input type="radio" id="estadoR" name="estadoTarea" value="R" <?php echo e((($_POST['estadoTarea'] ?? ($estadoTarea ?? '')) == "R") ? "checked" : ""); ?> <?php echo e($disableOperatorFields ? 'disabled' : ''); ?>> <label
                for="estadoR">Realizada</label></span>
        <span class="radio-group-item"><input type="radio" id="estadoC" name="estadoTarea" value="C" <?php echo e((($_POST['estadoTarea'] ?? ($estadoTarea ?? '')) == "C") ? "checked" : ""); ?> <?php echo e($disableOperatorFields ? 'disabled' : ''); ?>> <label
                for="estadoC">Cancelada</label></span>

        <label>Operario encargado:</label><br>
        <select name="operarioEncargado">
            <option value="">Seleccione operario</option>
            <?php if(isset($operarios) && is_array($operarios)): ?>
                <?php $__currentLoopData = $operarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($op['nombre']); ?>" <?php echo e((($_POST['operarioEncargado'] ?? ($operarioEncargado ?? '')) == $op['nombre']) ? "selected" : ""); ?>>
                        <?php echo e($op['nombre']); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select><br><br>

        <label>Fecha de realización:</label><br>
        <input type="date" name="fechaRealizacion"
            value="<?php echo e(htmlspecialchars($_POST['fechaRealizacion'] ?? ($fechaRealizacion ?? ''))); ?>" <?php echo e($disableOperatorFields ? 'disabled' : ''); ?>><br>
        <?php if($disableOperatorFields): ?>
             <input type="hidden" name="fechaRealizacion" value="<?php echo e($_POST['fechaRealizacion'] ?? ($fechaRealizacion ?? '')); ?>">
        <?php endif; ?>
        <?php if($msg = \App\Models\M_Funciones::getError('fecha_realizacion')): ?>
            <div class="error"><?php echo e($msg); ?></div>
        <?php endif; ?>


        <br>

        <label for="anotacionesAnteriores">Anotaciones anteriores:</label><br>
        <textarea id="anotacionesAnteriores"
            name="anotacionesAnteriores" readonly><?php echo e(htmlspecialchars($_POST['anotacionesAnteriores'] ?? ($anotacionesAnteriores ?? ''))); ?></textarea><br><br>

        <label for="anotacionesPosteriores">Anotaciones posteriores:</label><br>
        <textarea id="anotacionesPosteriores"
            name="anotacionesPosteriores"><?php echo e(htmlspecialchars($_POST['anotacionesPosteriores'] ?? ($anotacionesPosteriores ?? ''))); ?></textarea><br><br>

        <label for="fichero_resumen">Fichero resumen:</label>
        <?php if(!empty($ficherosResumen)): ?>
            <div class="file-item">
                <a href="<?php echo e(url('evidencias/' . $id . '/' . $ficherosResumen[0])); ?>" target="_blank"><?php echo e($ficherosResumen[0]); ?></a>
                <button type="submit" form="form-delete-resumen-admin" class="btn-danger" style="font-size: 0.8em; padding: 2px 5px;">Eliminar</button>
            </div>
        <?php else: ?>
            <input type="file" id="fichero_resumen" name="fichero_resumen"><br><br>
        <?php endif; ?>

        <label for="fotos">Fotos del trabajo:</label>
        <?php if(!empty($fotos)): ?>
            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="file-item">
                    <a href="<?php echo e(url('evidencias/' . $id . '/' . $foto)); ?>" target="_blank"><?php echo e($foto); ?></a>
                    <button type="submit" form="form-delete-foto-admin-<?php echo e(md5($foto)); ?>" class="btn-danger" style="font-size: 0.8em; padding: 2px 5px;">Eliminar</button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <input type="file" id="fotos" name="fotos[]" multiple><br><br>

        <?php if(isset($id)): ?><input type="hidden" name="id" value="<?php echo e($id); ?>"><?php endif; ?>
        <?php
            $rutaBase = (isset($_SESSION['rol']) && $_SESSION['rol'] === 'operario') ? 'operario/tareas' : 'admin/tareas';
        ?>
        <a class="btn btn-cancel" href="<?php echo e(url($rutaBase)); ?>">Cancelar</a>
        <input type="submit" value="<?php echo e(isset($id) ? 'Guardar cambios' : 'Crear tarea'); ?>">
    </form>
    
    <?php if(isset($id) && !empty($ficherosResumen)): ?>
         <form id="form-delete-resumen-admin" action="<?php echo e(url('admin/tareas/eliminar-fichero')); ?>" method="POST" style="display:none;">
             <?php echo csrf_field(); ?>
             <input type="hidden" name="id" value="<?php echo e($id); ?>">
             <input type="hidden" name="filename" value="<?php echo e($ficherosResumen[0]); ?>">
         </form>
    <?php endif; ?>
    <?php if(isset($id) && !empty($fotos)): ?>
        <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form id="form-delete-foto-admin-<?php echo e(md5($foto)); ?>" action="<?php echo e(url('admin/tareas/eliminar-fichero')); ?>" method="POST" style="display:none;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <input type="hidden" name="filename" value="<?php echo e($foto); ?>">
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\SERVIDOR\gestor\resources\views/tareas/form.blade.php ENDPATH**/ ?>