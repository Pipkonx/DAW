

<?php $__env->startSection('titulo', 'Gestión de Usuarios'); ?>

<?php $__env->startSection('cuerpo'); ?>
    <h1>Gestión de Usuarios</h1>

    <?php if(session('success')): ?>
        <aside>
            <?php echo e(session('success')); ?>

        </aside>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <aside>
            <?php echo e(session('error')); ?>

        </aside>
    <?php endif; ?>

    <p>
        <a href="/EjerciciosBasicos/SERVIDOR/admin/usuarios/crear" class="button">Crear Nuevo Usuario</a>
        <a href="/EjerciciosBasicos/SERVIDOR/admin/tareas" class="button">Volver a Tareas</a>
    </p>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Rol</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($usuario['id']); ?></td>
                    <td><?php echo e($usuario['nombre']); ?></td>
                    <td><?php echo e($usuario['rol']); ?></td>
                    <td>
                        <a href="/EjerciciosBasicos/SERVIDOR/admin/usuarios/editar?id=<?php echo e($usuario['id']); ?>" class="button">Editar</a>
                        <a href="/EjerciciosBasicos/SERVIDOR/admin/usuarios/confirmarEliminar?id=<?php echo e($usuario['id']); ?>" class="button">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">No hay usuarios registrados.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="pagination">
        <?php for($i = 1; $i <= $totalPaginas; $i++): ?>
            <a href="/EjerciciosBasicos/SERVIDOR/admin/usuarios?pagina=<?php echo e($i); ?>" class="button <?php echo e($i == $paginaActual ? 'active' : ''); ?>"><?php echo e($i); ?></a>
        <?php endfor; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\SERVIDOR\gestor\resources\views/usuarios/listar.blade.php ENDPATH**/ ?>