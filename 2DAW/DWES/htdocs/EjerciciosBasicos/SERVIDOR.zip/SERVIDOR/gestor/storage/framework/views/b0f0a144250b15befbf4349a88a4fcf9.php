<?php $__env->startSection('titulo', 'Alta de Tarea'); ?>

<?php $__env->startSection('estilos'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('cuerpo'); ?>
   <h1>Alta de Tarea</h1>
   <?php if(!empty($errorGeneral)): ?>
   <div class="error"><?php echo e($errorGeneral); ?></div>
   <?php endif; ?>
   <?php if(!empty($mensaje)): ?>
   <div class="msg"><?php echo e($mensaje); ?></div>
   <?php endif; ?>

   <?php echo $__env->make('tareas/form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/plantilla01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/vhosts/ieslamarisma.net/httpdocs/proyectos/2026/rafaelcordero/gestor/resources/views/tareas/alta_edicion.blade.php ENDPATH**/ ?>