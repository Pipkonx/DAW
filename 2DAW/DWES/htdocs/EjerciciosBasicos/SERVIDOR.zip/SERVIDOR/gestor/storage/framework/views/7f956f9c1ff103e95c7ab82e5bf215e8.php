<?php $__env->startSection('titulo', 'Crear Usuario'); ?>

<?php $__env->startSection('cuerpo'); ?>
    <h1>Crear Nuevo Usuario</h1>

    <?php if(isset($errores) && count($errores) > 0): ?>
        <aside>
            <ul>
                <?php $__currentLoopData = $errores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </aside>
    <?php endif; ?>

    <form action="/EjerciciosBasicos/SERVIDOR/admin/usuarios/crear" method="POST">
        <?php echo csrf_field(); ?>
        <p>
            <label for="nombre">Nombre</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre', $usuario->nombre ?? '')); ?>" required>
        </p>
        <p>
            <label for="contraseña">Contraseña</label>
            <input type="password" id="contraseña" name="contraseña" required>
        </p>
        <p>
            <label for="confirmar_contraseña">Confirmar Contraseña</label>
            <input type="password" id="confirmar_contraseña" name="confirmar_contraseña" required>
        </p>
        <p>
            <label for="rol">Rol</label>
            <select id="rol" name="rol" required>
                <option value="admin" <?php echo e((old('rol', $usuario->rol ?? '') == 'admin') ? 'selected' : ''); ?>>Administrador</option>
                <option value="operario" <?php echo e((old('rol', $usuario->rol ?? '') == 'operario') ? 'selected' : ''); ?>>Operario</option>
            </select>
        </p>
        <p>
            <button type="submit">Guardar</button>
            <a href="/EjerciciosBasicos/SERVIDOR/admin/usuarios" class="button">Cancelar</a>
        </p>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\SERVIDOR\gestor\resources\views/usuarios/crear.blade.php ENDPATH**/ ?>