<?php $__env->startSection('titulo', 'Login'); ?>

<?php $__env->startSection('cuerpo'); ?>
  <h1>Login</h1>
  <?php if(!empty($errorGeneral)): ?>
    <div class="error"><?php echo e($errorGeneral); ?></div>
  <?php endif; ?>
  <?php if(!empty($mensaje)): ?>
    <div class="msg"><?php echo e($mensaje); ?></div>
  <?php endif; ?>

  <form action="login" method="POST">
    <?php echo csrf_field(); ?>
        <div class="fila-formulario">
      <label class="etiqueta-fila-formulario">Usuario:</label>
      <input type="text" name="usuario" value="<?php echo e($nombre ?? ''); ?>">
    </div>

        <div class="fila-formulario">
      <label class="etiqueta-fila-formulario">Contraseña:</label>
      <input type="password" name="clave" value="<?php echo e($contraseña ?? ''); ?>">
    </div>
        <div class="fila-formulario">
      <label class="inline">
        <input type="checkbox" name="guardar_clave" <?php echo e(!empty($guardar_clave) ? 'checked' : ''); ?>> Guardar clave
      </label>
    </div>

    <div class="nav">
      <button type="submit" class="btn">Entrar</button>

    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\intentosProyecto\05_Ejemplo\resources\views/autenticacion/login.blade.php ENDPATH**/ ?>