<?php $__env->startSection('titulo', 'Confirmar eliminación'); ?>

<?php $__env->startSection('cuerpo'); ?>
  <h1>Confirmar eliminación</h1>
  <p>Vas a eliminar la tarea <strong>#<?php echo e($id); ?></strong>.</p>
  <ul>
    <li><strong>Persona:</strong> <?php echo e($personaNombre ?? ''); ?></li>
    <li><strong>Descripción:</strong> <?php echo e($descripcionTarea ?? ''); ?></li>
    <li><strong>Fecha:</strong> <?php echo e($fechaRealizacion ?? ''); ?></li>
    <li><strong>Estado:</strong> <?php echo e($estadoTarea ?? ''); ?></li>
  </ul>

  <div class="nav">
    <a href="<?php echo e(url('admin/tareas')); ?>" class="btn btn-cancel">Cancelar</a>
    <form action="<?php echo e(url('admin/tareas/eliminar')); ?>" method="POST"
      class="inline">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($id); ?>">
      <button type="submit" class="btn">Confirmar eliminación</button>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/plantilla01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\intentosProyecto\05_Ejemplo\resources\views/tareas/confirmar_eliminacion.blade.php ENDPATH**/ ?>