<?php $__env->startSection('titulo', 'Actualizar tarea (Operario)'); ?>

<?php $__env->startSection('cuerpo'); ?>
  <h1>Actualizar tarea (Operario)</h1>
  <?php if(!empty($errorGeneral)): ?>
    <div class="error"><?php echo e($errorGeneral); ?></div>
  <?php endif; ?>
  
  <div class="form-container">
  <form action="<?php echo e($formActionUrl); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if(isset($id)): ?><input type="hidden" name="id" value="<?php echo e($id); ?>"><?php endif; ?>

    <!-- Read Only Details -->
    <div class="details-section">
        <p><strong>NIF/CIF:</strong> <?php echo e($nifCif ?? ''); ?></p>
        <p><strong>Persona:</strong> <?php echo e($personaNombre ?? ''); ?></p>
        <p><strong>Teléfono:</strong> <?php echo e($telefono ?? ''); ?></p>
        <p><strong>Correo:</strong> <?php echo e($correo ?? ''); ?></p>
        <p><strong>Descripción:</strong> <?php echo e($descripcionTarea ?? ''); ?></p>
        <p><strong>Dirección:</strong> <?php echo e($direccionTarea ?? ''); ?>, <?php echo e($poblacion ?? ''); ?> (<?php echo e($provincia ?? ''); ?>)</p>
    </div>
    <hr>

    <!-- Editable Fields -->
    <label>Estado:</label><br>
    <select name="estadoTarea">
      <option value="R" <?php echo e((($estadoTarea ?? '') == 'R') ? 'selected' : ''); ?>>Completada</option>
      <option value="C" <?php echo e((($estadoTarea ?? '') == 'C') ? 'selected' : ''); ?>>Cancelada</option>
    </select><br>
    <?php if($msg = \App\Models\M_Funciones::getError('estadoTarea')): ?>
      <div class="error"><?php echo e($msg); ?></div>
    <?php endif; ?>
    <br>

    <label>Fecha de realización:</label><br>
    <input type="date" name="fechaRealizacion" value="<?php echo e($fechaRealizacion ?? ''); ?>"><br>
    <?php if($msg = \App\Models\M_Funciones::getError('fecha_realizacion')): ?>
        <div class="error"><?php echo e($msg); ?></div>
    <?php endif; ?>
    <br>

    <label>Anotaciones anteriores:</label><br>
    <textarea readonly disabled><?php echo e($anotacionesAnteriores ?? ''); ?></textarea>
    <input type="hidden" name="anotacionesAnteriores" value="<?php echo e($anotacionesAnteriores ?? ''); ?>">
    <br><br>

    <label>Anotaciones posteriores:</label><br>
    <textarea name="anotacionesPosteriores"><?php echo e($anotacionesPosteriores ?? ''); ?></textarea><br>
    <?php if($msg = \App\Models\M_Funciones::getError('anotacionesPosteriores')): ?>
      <div class="error"><?php echo e($msg); ?></div>
    <?php endif; ?>
    <br><br>

    <!-- Files -->
    <label>Fichero resumen:</label><br>
    <?php if(!empty($ficherosResumen)): ?>
        <div class="file-item">
            <a href="<?php echo e(url('evidencias/' . $id . '/' . $ficherosResumen[0])); ?>" target="_blank"><?php echo e($ficherosResumen[0]); ?></a>
            <button type="submit" form="form-delete-resumen" class="btn-danger" style="font-size: 0.8em; padding: 2px 5px;">Eliminar</button>
        </div>
    <?php else: ?>
        <input type="file" name="fichero_resumen"><br>
    <?php endif; ?>
    <br>

    <label>Fotos (evidencias):</label><br>
    <?php if(!empty($fotos)): ?>
        <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="file-item">
                <a href="<?php echo e(url('evidencias/' . $id . '/' . $foto)); ?>" target="_blank"><?php echo e($foto); ?></a>
                <button type="submit" form="form-delete-foto-<?php echo e(md5($foto)); ?>" class="btn-danger" style="font-size: 0.8em; padding: 2px 5px;">Eliminar</button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <input type="file" name="fotos[]" multiple><br><br>

    <button type="submit" class="btn">Guardar</button>
    <a href="<?php echo e(url('operario/tareas')); ?>" class="btn btn-cancel">Cancelar</a>
  </form>

  <!-- Hidden Delete Forms -->
  <?php if(!empty($ficherosResumen)): ?>
     <form id="form-delete-resumen" action="<?php echo e(url('operario/tareas/eliminar-fichero')); ?>" method="POST" style="display:none;">
         <?php echo csrf_field(); ?>
         <input type="hidden" name="id" value="<?php echo e($id); ?>">
         <input type="hidden" name="filename" value="<?php echo e($ficherosResumen[0]); ?>">
     </form>
  <?php endif; ?>
  <?php if(!empty($fotos)): ?>
    <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form id="form-delete-foto-<?php echo e(md5($foto)); ?>" action="<?php echo e(url('operario/tareas/eliminar-fichero')); ?>" method="POST" style="display:none;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($id); ?>">
            <input type="hidden" name="filename" value="<?php echo e($foto); ?>">
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/plantilla01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\intentosProyecto\05_Ejemplo\resources\views/tareas/edicion_operario.blade.php ENDPATH**/ ?>