<?php $__env->startSection('contenido'); ?>
    <h1><?php echo e($modo == 'alta' ? 'Crear Nuevo Usuario' : 'Editar Usuario'); ?></h1>

    <?php if(isset($errores)): ?>
        <div class="alert error">
            <ul>
                <?php $__currentLoopData = $errores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e($modo == 'alta' ? url('/admin/usuarios/crear') : url('/admin/usuarios/editar')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if($modo == 'edicion'): ?>
            <input type="hidden" name="id" value="<?php echo e($usuario['id'] ?? ''); ?>">
        <?php endif; ?>

        <div class="form-group">
            <label for="nombre">Nombre de Usuario:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo e($usuario['nombre'] ?? ''); ?>" required>
        </div>

        <div class="form-group">
            <label for="contraseña">Contraseña:</label>
            <input type="password" id="contraseña" name="contraseña" <?php echo e($modo == 'alta' ? 'required' : ''); ?>>
            <?php if($modo == 'edicion'): ?>
                <small>Dejar en blanco para mantener la contraseña actual.</small>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="confirmar_contraseña">Confirmar Contraseña:</label>
            <input type="password" id="confirmar_contraseña" name="confirmar_contraseña" <?php echo e($modo == 'alta' ? 'required' : ''); ?>>
        </div>

        <div class="form-group">
            <label for="rol">Rol:</label>
            <select id="rol" name="rol" required>
                <option value="">Seleccione un rol</option>
                <option value="admin" <?php echo e((isset($usuario) && $usuario['rol'] == 'admin') ? 'selected' : ''); ?>>Administrador</option>
                <option value="operario" <?php echo e((isset($usuario) && $usuario['rol'] == 'operario') ? 'selected' : ''); ?>>Operario</option>
            </select>
        </div>

        <button type="submit" class="btn"><?php echo e($modo == 'alta' ? 'Crear Usuario' : 'Actualizar Usuario'); ?></button>
        <a href="<?php echo e(url('/admin/usuarios')); ?>" class="btn secondary">Cancelar</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\SERVIDOR\gestor\resources\views/usuarios/alta_edicion.blade.php ENDPATH**/ ?>