<?php $__env->startSection('titulo', 'Confirmar Eliminación'); ?>

<?php $__env->startSection('cuerpo'); ?>
    <h1>Confirmar Eliminación de Usuario</h1>

    <aside>
        <p>¿Estás seguro de que deseas eliminar al usuario <strong><?php echo e($usuario['nombre']); ?></strong> (ID: <?php echo e($usuario['id']); ?>)?</p>
        <p>Esta acción no se puede deshacer.</p>
    </aside>

    <form action="/EjerciciosBasicos/SERVIDOR/admin/usuarios/eliminar" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($usuario['id']); ?>">
        <p>
            <button type="submit">Eliminar</button>
            <a href="/EjerciciosBasicos/SERVIDOR/admin/usuarios" class="button">Cancelar</a>
        </p>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillas.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rafael\Desktop\DAW\2DAW\DWES\htdocs\EjerciciosBasicos\SERVIDOR\gestor\resources\views/usuarios/confirmar_eliminacion.blade.php ENDPATH**/ ?>