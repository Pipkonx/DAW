<?php $__env->startSection('titulo', 'Detalle de tarea'); ?>

<?php $__env->startSection('cuerpo'); ?>
  <h1>Detalle de tarea #<?php echo e($id); ?></h1>
  <table>
    <tr><th>Persona</th><td><?php echo e($personaNombre); ?></td></tr>
    <tr><th>Correo</th><td><?php echo e($correo); ?></td></tr>
    <tr><th>Teléfono</th><td><?php echo e($telefono); ?></td></tr>
    <tr><th>Descripción</th><td><?php echo e($descripcionTarea); ?></td></tr>
    <tr><th>Dirección</th><td><?php echo e($direccionTarea); ?></td></tr>
    <tr><th>Población</th><td><?php echo e($poblacion); ?></td></tr>
    <tr><th>Código Postal</th><td><?php echo e($codigoPostal); ?></td></tr>
    <tr><th>Provincia</th><td><?php echo e($provincia); ?></td></tr>
    <tr><th>Estado</th><td><?php echo e($estadoTarea); ?></td></tr>
    <tr><th>Operario</th><td><?php echo e($operarioEncargado); ?></td></tr>
    <tr><th>Fecha realización</th><td><?php echo e($fechaRealizacion); ?></td></tr>
    <tr><th>Anotaciones anteriores</th><td><?php echo e($anotacionesAnteriores); ?></td></tr>
    <tr><th>Anotaciones posteriores</th><td><?php echo e($anotacionesPosteriores); ?></td></tr>
  </table>
  <div class="nav">
    <?php
        $rutaBase = (isset($_SESSION['rol']) && $_SESSION['rol'] === 'operario') ? 'operario/tareas' : 'admin/tareas';
    ?>
    <a href="<?php echo e(url($rutaBase)); ?>" class="btn">Volver</a>
    <a href="<?php echo e(url($rutaBase . '/editar?id=' . $id)); ?>" class="btn">Editar</a>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/plantilla01', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/vhosts/ieslamarisma.net/httpdocs/proyectos/2026/rafaelcordero/gestor/resources/views/tareas/detalle.blade.php ENDPATH**/ ?>