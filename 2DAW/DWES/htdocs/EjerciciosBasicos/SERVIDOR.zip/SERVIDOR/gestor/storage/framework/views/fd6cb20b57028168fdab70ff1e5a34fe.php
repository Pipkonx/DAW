<!doctype html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title><?php echo $__env->yieldContent('titulo'); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body class="<?php echo e($isLoginPage ?? false ? 'login-page' : ''); ?>">

  <div class="container">
    <div class="header-actions">
      <?php if(!isset($isLoginPage) || !$isLoginPage): ?>
        
          <form action="<?php echo e(url('/logout')); ?>" method="POST" class="logout-form">

            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Cerrar Sesión</button>
          </form>
      <?php endif; ?>
    </div>
    <?php echo $__env->yieldContent('cuerpo'); ?>
  </div>
</body>

</html><?php /**PATH /var/www/vhosts/ieslamarisma.net/httpdocs/proyectos/2026/rafaelcordero/gestor/resources/views/layouts/plantilla01.blade.php ENDPATH**/ ?>