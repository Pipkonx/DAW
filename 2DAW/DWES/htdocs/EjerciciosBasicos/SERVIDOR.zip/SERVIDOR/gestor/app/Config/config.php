<?php
return [
  'host'=>'localhost',
  'user'=>'root',
  'pass'=>'',
  'db'=>'laravel'
];
