<?php
/**
 * Redirect to the public directory
 */
header('Location: public/');
exit;
